import flet as ft
#from flet import *


def main(page: ft.Page):
    #title
    page.title = "Flet Starter App"

    #theme
    page.theme_mode=ft.ThemeMode.LIGHT
    #page.padding=50


    page.update()


if __name__ == "__main__":
	ft.app(target=main)
	#ft.app(target=main, view=ft.AppView.WEB_BROWSER)